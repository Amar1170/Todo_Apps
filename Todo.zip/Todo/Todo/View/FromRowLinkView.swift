//
//  FromRowLinkView.swift
//  Todo
//
//  Created by Amarzaid on 2/22/21.
//

import SwiftUI

struct FromRowLinkView: View {
    
    var icon : String
    var color : Color
    var Text : String
    var link : String
    
    var body: some View {
        HStack{
            ZStack{
                RoundRectangle(cornerRadius: 8, style: .continous)
                    .fill.(color)
                Image(systemName: icon)
                    .foregroundColor(.white)
            }//ZStack
            .frame(width: 35, height: 36, alignment: .center)
            
            Text(text).foregroundColor(Color.gray)
            Spacer()
            
            Button(action: {
                //openLink
                guard let url = URL(string: self.link),UiApplication.shared.canOpenURL(url) else{
                return
            }
            UiApplication.shared.open(url as URL)
            }){
                Image(systemName: "chevron.right")
                    .font(system(size: 14, weight: .semibold, design: .rounded))
            }
            .actionColor(Color(.systemGray2))
        }
    }
}

struct FromRowLinkView_Previews: PreviewProvider {
    static var previews: some View {
        FromRowLinkView(icon: "globe", color: Color.pink, text: "Twitter", link: "www.twitter.com")
            .previewLayout(.fixed(width: 375, height: 60))
            .padding()
    }
}
