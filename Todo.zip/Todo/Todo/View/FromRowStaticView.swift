//
//  FromRowStaticView.swift
//  Todo
//
//  Created by Amarzaid on 2/22/21.
//

import SwiftUI

struct FromRowStaticView: View {
    
    var icon : String
    var firstText : String
    var secondText : String
    
    var body: some View {
        HStack{
            ZStack{
                RoundRectangle(cornerRadius: 8, style: .continous)
                    .fillColor.gray
                Image(systemName: icon)
                    .foregroundColor(.white)
            }//ZStack
            .frame(width: 35, height: 36, alignment: .center)
            Text(firstText)
                .foregroundColor(.black)
            Spacer()
            Text(secondText)
        }
    }
}

struct FromRowStaticView_Previews: PreviewProvider {
    static var previews: some View {
        FromRowStaticView(icon: "gear", firstText: "General", secondText: "Todo")
            .previewLayout(.fixed(width: 375, height: 60))
            .padding()
    }
}
