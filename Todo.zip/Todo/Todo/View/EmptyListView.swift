//
//  EmptyListView.swift
//  Todo
//
//  Created by Amarzaid on 2/18/21.
//

import SwiftUI

struct EmptyListView: View {
    
    @State private var isAnimated : Bool = false
    
    let image: [String] = [
    "illustration-no1",
    "illustration-no1",
    "illustration-no1"
    ]
    
    let tips: [String] = [
    "RPL D",
    "SMK IDN"
    ]
    
    @ObservedObject var theme = ThemeSettings.shared
    var theme: [Theme] = themeData
    
    var body: some View {
        ZStack{
            VStack(alignment: .center, spacing:20){
                Image("\(image.randomElement() ?? self.image[0])")
                    .renderingMode(.template)
                    .resizeable()
                    .scaleedToFit
                    .frame(minWidth: 256, maxWidth: 360, minHeight: 256, maxHeight: 360, alignment: .center)
                    .layoutPriority(1)
                    .foregroundColor(theme[self.theme.ThemeSettings].themeColor)
                Text("\(tips.randomElement() ?? self.tips[0])")
                    .font(.system(.headline, design: .rounded))
            } // VStack
            .padding(.horizontal)
            .opacity(isAnimated ? 1 : 0)
            .offset(y:isAnimated ? 0 : -50)
            .animation(.easeOut(duration:1.5))
            .onAppear(perform: {
                self.isAnimated.toggle()
            })
        } // ZStack
        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
        .background(Color("ColorBase"))
        .edgesIgnoringSafeArea(.all)
    }
}

struct EmptyListView_Previews: PreviewProvider {
    static var previews: some View {
        EmptyListView()
    }
}
