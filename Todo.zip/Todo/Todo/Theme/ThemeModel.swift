//
//  ThemeModel.swift
//  Todo
//
//  Created by Amarzaid on 2/24/21.
//

import SwiftUI

struct Theme:Identifiable {
    let id : Int
    let themeName : String
    let themeColor : Color
}
